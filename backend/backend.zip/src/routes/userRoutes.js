import express from "express";
import {
  registerUser,
  loginUser,
  userDashboard,
  updateName,
  updatePassword,
  deleteUser,
} from "../controllers/userControllers.js";
import { authToken } from "../middleware/auth.js";
const router = express.Router();
router.post("/register", registerUser);
router.post("/login", loginUser);
router.get("/dashboard/profile", authToken, userDashboard);
router.put("/dashboard/profile/name", authToken, updateName);
router.put("/dashboard/profile/password", authToken, updatePassword);
router.delete("/dashboard/profile/delete", authToken, deleteUser);
export default router;
